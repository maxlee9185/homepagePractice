var express = require('express');
var connection = require('../db/mysql');

var router = express.Router();

/* board list page */
router.get('/list', function(req, res, next) {

    connection.query('select *,date_format(cdate, \'%Y-%m-%d %H:%i:%s\') as cdate2 from t_board', function(err, rows){
        if(err) {
            res.render('boardList', {'status':'Error'});
        } else {
            res.render('boardList', {'status':'OK', 'data':rows}); //배열 형태로 넣었다
        }
    });
});


router.get('/search',function(req,res,next){
    const sql='select *,date_format(cdate, \'%Y-%m-%d %H:%i:%s\') as cdate2 from t_board where title like ?'
    const value=['\%'+req.query.key+'\%']
    connection.query(sql,value,function(err,rows){
        if (err){
            res.render('boardList',{'status':'Error'});
        }
        else{
            res.render('boardList',{'status':'OK','data':rows});
        }
    });
});
/* board Register page */
router.get('/register', function(req, res, next) {
    res.render('boardRegister');
});
/*board register process ajax */
router.post('/register/process',function(req,res,next){
    //request에서 body로 꺼내면 된다
    var sql='insert into t_board (user_id,user_name,title,content) '+ 'values(?,?,?,?)';
    var values=[req.session.login_id,req.session.user_name,req.body.board_title,req.body.board_content];
    connection.query(sql,values,function(err,result){
        if (err){
            res.json({'status':'Error'});
        }else {
            console.log(result);
            if(result.insertId !=0 ){
                res.json({'status':'OK'});
            }
            else{
                res.json({'status':'Error'});
            }
        }
    }); //insert해야한다
});



/* board Update page */
router.get('/update', function(req, res, next) {
    console.log(req.query.bid);
    connection.query(`Select * from t_board where bid=${req.query.bid}`,function(err,rows){
        console.log(rows[0]);
        if(err){
            res.render('boardUpdate',{'status':'Error'});
        }
        else{
            if(rows.length!==1){
                alert('게시물 못찾았어요');
            }
            else res.render('boardUpdate', {'status':'OK','data':rows[0]});
        }
    })
    
});

router.post('/update/modify', function(req, res, next) {
    const query=`update t_board set title =?, content =?, cdate =? where bid =?`
    console.log("bid",req.body.board_bid)
    const values=[req.body.board_title,req.body.board_content, new Date(), req.body.board_bid]
    connection.query(query,values,function(err,rows){
        console.log("update",rows,err)
        if(err){
            res.json({'status':'Error'});
        }
        else{
            if(rows.affectedRows===1){
                res.json({'status':'OK'});
            }
            else res.json({'status':'Error'});
        }
    });
    
});

router.post('/update/delete', function(req, res, next) {
    console.log(req.query.bid);
    const query=`Delete from t_board where bid=?`
    const values=req.body.board_bid
    connection.query(query,values,function(err,rows){
        if(err){
            res.json('boardUpdate',{'status':'Error'});
        }
        else{
            if(rows.affectedRows===1){
                res.json({'status':'OK'});
            }
            else res.json({'status':'Error'});
        }
    });
    
});





module.exports = router;
