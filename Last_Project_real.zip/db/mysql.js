var mysql = require('mysql');
module.exports = mysql.createConnection({
    host:'localhost',
    port:3309,
    user:'board_user',
    password:'skkutest',
    database:'board_db'
});